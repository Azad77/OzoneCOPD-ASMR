# Ozone-attributable COPD mortality, 1990–2023

A reproducible Das Gupta decomposition of Global Burden of Disease 2023 estimates for 204 countries.

**Azad Rasul** · [ORCID 0000-0001-5141-0577](https://orcid.org/0000-0001-5141-0577) · Department of Geography, Soran University, Erbil, Iraq

---

## What this is

When deaths attributable to an environmental hazard rise, how much of the rise is the environment
changing and how much is the population changing? This repository answers that for ambient ozone
and chronic obstructive pulmonary disease (COPD).

Attributable deaths are written as the product of three factors

```
D = PAF × R × N
```

— the population-attributable fraction, the crude background COPD death rate, and population size —
and the 1990–2023 change is decomposed into three **exactly additive** components using the
Das Gupta (1993) three-factor standardisation.

### Headline results

| | 1990 | 2023 |
|---|---|---|
| Global ozone-attributable COPD deaths | 172,584 (95% UI 39,323–329,062) | 468,719 (108,209–854,387) |

Change **+171.6%**, decomposed as:

| Component | Deaths | Share of change |
|---|---:|---:|
| Population size | +113,103 | 38.2% |
| Exposure (PAF) | +93,059 | 31.4% |
| Background COPD rate | +89,973 | 30.4% |

The three drivers are near-equal globally — but weighting by where the burden actually falls tells
a different story. **Countries in which exposure is the leading driver of the increase carry 62.6%
of the 2023 global burden**, against 27.7% for population size and 8.2% for the background rate.

A counterfactual holding the PAF at its 1990 value attributes **142,526 deaths — 30.4% of the 2023
burden — to the change in exposure since 1990**, of which 114,399 are in India. Where precursor
controls were implemented the sign reverses: high-income countries averted an estimated 4,295
deaths and Central and Eastern Europe 3,865.

---

## Quick start

```bash
git clone https://github.com/Azad77/OzoneCOPD-ASMR
cd OzoneCOPD-ASMR
pip install -r requirements.txt
jupyter lab            # run 01 → 02 → 03 from the repository root
```

Everything regenerates from `data/`. No network access and no API keys are needed.

| Notebook | Reads | Writes |
|---|---|---|
| `01_analysis.ipynb` | `data/*.csv` | `outputs/results.json`, `outputs/manuscript_numbers.csv`, Tables 1–6, country / region / income panels |
| `02_figures.ipynb` | `outputs/` | `outputs/figures/` — PNG (600 dpi), PDF (vector), TIFF (600 dpi, LZW) |
| `03_build_manuscript.ipynb` | `results.json` + tables + figures | `COPD_Ozone_Manuscript.docx` |

`02_figures.py` is a script twin of notebook 02, for running outside Jupyter.

---

## The point: no number is typed by hand

`01` writes every quantity the paper quotes into `outputs/results.json`. `03` injects those values
into the manuscript prose by f-string. **The manuscript cannot disagree with the analysis.** Change
a filter, a grouping or a year, re-run 01 → 02 → 03, and the abstract, results, discussion and
conclusions all update together.

When editing prose in `03`, interpolate values — never type them. That is the one rule that keeps
this property alive.

### Assertions that stop the pipeline

`01_analysis` halts rather than producing wrong output if any of these fail:

1. **Validation** — the reconstructed 204-country total must reconcile with the GBD-published
   global figure. It agrees to **0.02%** (468,719 vs 468,806).
2. **Additivity** — the Das Gupta residual must be zero. It is **2.9 × 10⁻¹¹**.
3. **Coverage** — all 204 countries must be classified into a super-region and an income group.

`03_build_manuscript` then re-opens the finished `.docx` and asserts the headline values are
physically present in it.

### Audit trail

`outputs/manuscript_numbers.csv` maps every value quoted in the manuscript to the section it
appears in. A reviewer's question about any figure in the text resolves to one row there and one
cell in `01_analysis`.

### Cross-platform check

The pipeline has been run on three independent Python environments and reproduces **identically to
the last digit**, including the floating-point residual:

| Python | NumPy | pandas | matplotlib |
|---|---|---|---|
| 3.11 | 1.26 | 2.2 | 3.8 |
| 3.12 | 2.5.1 | 3.0.3 | — |
| 3.11 | 2.4.6 | 3.0.3 | 3.11.0 |

---

## Repository layout

```
01_analysis.ipynb              data → results
02_figures.ipynb               results → figures
02_figures.py                  script twin of 02
03_build_manuscript.ipynb      results + figures → .docx
gbd_hierarchy.py               204-country GBD super-region + World Bank income lookup
world_robinson.json            Natural Earth 110 m outlines, pre-projected (Robinson)
country_iso3.csv               GBD name → ISO-3 crosswalk (fallback if pycountry absent)
requirements.txt
data/                          the five IHME GBD extracts + IHME citation
outputs/                       results.json, Tables 1–6, figures, full country panel
COPD_Ozone_Manuscript.docx     the manuscript, built by notebook 03
```

### The maps use no GIS stack

No GeoPandas, Shapely, Fiona, PROJ or GDAL. Those are compiled extensions, and a mismatch between
the NumPy / GEOS / PROJ versions they were each built against crashes the interpreter outright
rather than raising a Python exception — a poor property for a pipeline others must reproduce.

Country outlines instead ship as `world_robinson.json` (130 KB), already projected to Robinson and
stored in kilometres, drawn with `matplotlib.path` directly. The code that generated that file is
recorded in an appendix cell of `02_figures.ipynb` for provenance.

---

## Method notes, and what the data cannot support

Every GBD extract here is `age = "All ages"`, `sex = "Both"`. Two consequences follow, and the
manuscript states both explicitly:

- **The population term is population *size*.** No ageing component is identifiable, and no claim
  about ageing is made anywhere.
- **The background-rate term is a *crude* rate**, so it absorbs the ageing signal. It is not a
  measure of clinical progress in COPD care.
- **All rates reported are crude.** Age-standardised rates require `age = "Age-standardized"`
  (age_id 27), which is not in these extracts.

Separating population growth from population ageing requires an age-stratified re-download and a
four-factor decomposition. That is identified as the principal extension of this work rather than
implied to be already done.

The uncertainty analysis is a **bounding exercise, not a propagation** — it assumes the interval
bounds are perfectly correlated across countries and years. Valid propagation needs the GBD
posterior draws, which are not in the public extracts. It is reported in full, including where it
is uninformative.

### On the exact Das Gupta weights

For a three-factor product, the familiar shortcut `(P₁−P₀) · ½(R₀+R₁) · ½(N₀+N₁)` is **not
additive** and leaves a residual — 5,952 deaths on these data, with component shares summing to
98.6%–114% instead of 100%. The correct standardisation puts 1/3 on matched cross-products and 1/6
on mismatched:

```
Δ_PAF = (PAF₁ − PAF₀) × [ (R₀N₀ + R₁N₁)/3 + (R₁N₀ + R₀N₁)/6 ]
```

with the R and N components defined symmetrically. `01_analysis` computes both and asserts the
exact version's residual is zero.

---

## Data

`data/` holds the five extracts downloaded from the [GBD Results tool](https://vizhub.healthdata.org/gbd-results/):

| File | Contents |
|---|---|
| `IHME-GBD_1990_DATA.csv` | ozone-attributable COPD deaths + DALYs, 1990 |
| `IHME-GBD_2023_DATA.csv` | ozone-attributable COPD deaths + DALYs, 2023 |
| `IHME-GBD_2023_DATA-82346a3c-1.csv` | total COPD deaths (all risks), 1990 + 2023 |
| `IHME-GBD_2023_DATA-d283b20d-1.csv` | population, 1990 + 2023 |
| `IHME-GBD_2023_DATA-6c5a02c2-1.csv` | GBD-published Global row (validation only) |

> **A trap worth knowing about.** The attributable-burden files contain both `measure = "Deaths"`
> and `measure = "DALYs"` rows under `metric = "Number"`. Filtering on `metric` alone and then
> aggregating silently adds a death count to a DALY count — inflating the global 2023 figure from
> 468,719 to 8,925,489. `01_analysis` prints both sums side by side so the mistake cannot be made
> quietly. Anyone working with GBD extracts should filter on `measure` as well as `metric`.

Please cite IHME as in `data/citation.txt` when using these data.

---

## Citation

> Global Burden of Disease Collaborative Network (2025). *Global Burden of Disease Study 2023
> (GBD 2023) Results.* Institute for Health Metrics and Evaluation, Seattle.
> https://vizhub.healthdata.org/gbd-results/

> Das Gupta, P. (1993). *Standardization and decomposition of rates: a user's manual.*
> US Bureau of the Census, Current Population Reports Series P23-186.

For this repository, see `CITATION.cff`.

## Licence

Code: MIT (see `LICENSE`). The GBD extracts in `data/` remain subject to the IHME Free-of-Charge
Non-Commercial User Agreement. Country outlines derive from Natural Earth (public domain).
