"""GBD 2023 super-region and World Bank income-group assignments for all 204 GBD countries.

SUPER_REGION follows the GBD location hierarchy (7 super-regions).
INCOME_GROUP follows the World Bank classification (FY2025). Small territories that
the World Bank does not classify are marked 'Unclassified' rather than silently dropped.

Both dictionaries are keyed on the EXACT GBD location_name string used in the
IHME extracts, so no name normalisation is required and nothing falls through.
"""

SUPER_REGION = {}
INCOME_GROUP = {}

_SR = {
"High-income": [
 "Brunei Darussalam","Japan","Singapore","Republic of Korea",
 "Andorra","Austria","Belgium","Cyprus","Denmark","Finland","France","Germany","Greece",
 "Greenland","Iceland","Ireland","Israel","Italy","Luxembourg","Malta","Monaco",
 "Netherlands","Norway","Portugal","San Marino","Spain","Sweden","Switzerland","United Kingdom",
 "Australia","New Zealand",
 "Bermuda","Canada","United States of America",
 "Argentina","Chile","Uruguay"],
"Central Europe, Eastern Europe, and Central Asia": [
 "Albania","Bosnia and Herzegovina","Bulgaria","Croatia","Czechia","Hungary","Montenegro",
 "North Macedonia","Poland","Romania","Serbia","Slovakia","Slovenia",
 "Belarus","Estonia","Latvia","Lithuania","Republic of Moldova","Russian Federation","Ukraine",
 "Armenia","Azerbaijan","Georgia","Kazakhstan","Kyrgyzstan","Mongolia","Tajikistan",
 "Turkmenistan","Uzbekistan"],
"Latin America and Caribbean": [
 "Bolivia (Plurinational State of)","Ecuador","Peru",
 "Antigua and Barbuda","Bahamas","Barbados","Belize","Cuba","Dominica","Dominican Republic",
 "Grenada","Guyana","Haiti","Jamaica","Puerto Rico","Saint Kitts and Nevis","Saint Lucia",
 "Saint Vincent and the Grenadines","Suriname","Trinidad and Tobago","United States Virgin Islands",
 "Colombia","Costa Rica","El Salvador","Guatemala","Honduras","Mexico","Nicaragua","Panama",
 "Venezuela (Bolivarian Republic of)",
 "Brazil","Paraguay"],
"North Africa and Middle East": [
 "Afghanistan","Algeria","Bahrain","Egypt","Iran (Islamic Republic of)","Iraq","Jordan","Kuwait",
 "Lebanon","Libya","Morocco","Oman","Palestine","Qatar","Saudi Arabia","Sudan",
 "Syrian Arab Republic","Tunisia","Türkiye","United Arab Emirates","Yemen"],
"South Asia": ["Bangladesh","Bhutan","India","Nepal","Pakistan"],
"Southeast Asia, East Asia, and Oceania": [
 "China","Democratic People's Republic of Korea","Taiwan",
 "Cambodia","Indonesia","Lao People's Democratic Republic","Malaysia","Maldives","Mauritius",
 "Myanmar","Philippines","Seychelles","Sri Lanka","Thailand","Timor-Leste","Viet Nam",
 "American Samoa","Cook Islands","Fiji","Guam","Kiribati","Marshall Islands",
 "Micronesia (Federated States of)","Nauru","Niue","Northern Mariana Islands","Palau",
 "Papua New Guinea","Samoa","Solomon Islands","Tokelau","Tonga","Tuvalu","Vanuatu"],
"Sub-Saharan Africa": [
 "Angola","Central African Republic","Congo","Democratic Republic of the Congo",
 "Equatorial Guinea","Gabon",
 "Burundi","Comoros","Djibouti","Eritrea","Ethiopia","Kenya","Madagascar","Malawi","Mozambique",
 "Rwanda","Somalia","South Sudan","Uganda","United Republic of Tanzania","Zambia",
 "Botswana","Eswatini","Lesotho","Namibia","South Africa","Zimbabwe",
 "Benin","Burkina Faso","Cabo Verde","Cameroon","Chad","Côte d'Ivoire","Gambia","Ghana","Guinea",
 "Guinea-Bissau","Liberia","Mali","Mauritania","Niger","Nigeria","Sao Tome and Principe",
 "Senegal","Sierra Leone","Togo"],
}
for k, v in _SR.items():
    for c in v:
        SUPER_REGION[c] = k

_IG = {
"High-income": [
 "Andorra","Antigua and Barbuda","Australia","Austria","Bahamas","Bahrain","Barbados","Belgium",
 "Bermuda","Brunei Darussalam","Bulgaria","Canada","Chile","Croatia","Cyprus","Czechia","Denmark",
 "Estonia","Finland","France","Germany","Greece","Greenland","Guam","Guyana","Hungary","Iceland",
 "Ireland","Israel","Italy","Japan","Kuwait","Latvia","Lithuania","Luxembourg","Malta","Monaco",
 "Nauru","Netherlands","New Zealand","Northern Mariana Islands","Norway","Oman","Palau","Panama",
 "Poland","Portugal","Puerto Rico","Qatar","Republic of Korea","Romania","Russian Federation",
 "Saint Kitts and Nevis","San Marino","Saudi Arabia","Seychelles","Singapore","Slovakia",
 "Slovenia","Spain","Sweden","Switzerland","Taiwan","Trinidad and Tobago","United Arab Emirates",
 "United Kingdom","United States Virgin Islands","United States of America","Uruguay",
 "American Samoa"],
"Upper-middle income": [
 "Albania","Argentina","Armenia","Azerbaijan","Belarus","Belize","Bosnia and Herzegovina",
 "Botswana","Brazil","China","Colombia","Costa Rica","Cuba","Dominica","Dominican Republic",
 "Ecuador","Equatorial Guinea","Fiji","Gabon","Georgia","Grenada","Indonesia",
 "Iran (Islamic Republic of)","Iraq","Jamaica","Kazakhstan","Libya","Malaysia","Maldives",
 "Marshall Islands","Mauritius","Mexico","Montenegro","Namibia","North Macedonia","Palestine",
 "Paraguay","Peru","Saint Lucia","Saint Vincent and the Grenadines","Serbia","South Africa",
 "Suriname","Thailand","Tonga","Turkmenistan","Türkiye","Tuvalu"],
"Lower-middle income": [
 "Algeria","Angola","Bangladesh","Benin","Bhutan","Bolivia (Plurinational State of)",
 "Cabo Verde","Cambodia","Cameroon","Comoros","Congo","Côte d'Ivoire","Djibouti","Egypt",
 "El Salvador","Eswatini","Ghana","Guatemala","Guinea","Haiti","Honduras","India",
 "Jordan","Kenya","Kiribati","Kyrgyzstan","Lao People's Democratic Republic","Lebanon","Lesotho",
 "Mauritania","Micronesia (Federated States of)","Mongolia","Morocco","Myanmar","Nepal",
 "Nicaragua","Nigeria","Pakistan","Papua New Guinea","Philippines","Samoa",
 "Sao Tome and Principe","Senegal","Solomon Islands","Sri Lanka","Tajikistan","Timor-Leste",
 "Tunisia","Ukraine","United Republic of Tanzania","Uzbekistan","Vanuatu","Viet Nam","Zambia",
 "Zimbabwe","Republic of Moldova","Venezuela (Bolivarian Republic of)","Cook Islands"],
"Low-income": [
 "Afghanistan","Burkina Faso","Burundi","Central African Republic","Chad",
 "Democratic People's Republic of Korea","Democratic Republic of the Congo","Eritrea","Ethiopia",
 "Gambia","Guinea-Bissau","Liberia","Madagascar","Malawi","Mali","Mozambique","Niger","Rwanda",
 "Sierra Leone","Somalia","South Sudan","Sudan","Syrian Arab Republic","Togo","Uganda","Yemen"],
"Unclassified": ["Niue","Tokelau"],
}
for k, v in _IG.items():
    for c in v:
        INCOME_GROUP[c] = k
