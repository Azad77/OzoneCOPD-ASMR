"""02_figures_fixed.py — terminal twin of 02_figures_fixed.ipynb.

Run this from a command prompt when the Jupyter kernel dies without an error:
    cd /d D:\\air_pollution_GBD_2023\\opus_revised
    python 02_figures_fixed.py

A terminal shows the real OS-level failure (segfault, DLL load error, NumPy ABI
mismatch) that VS Code reports only as "the kernel crashed".
Progress is also appended to outputs/figures/_run_log.txt.
"""

# ---------------------------------------------------------------- preflight
# Imports one thing at a time and logs each step to disk, so a crash leaves a trace
# even though the notebook's own outputs are lost.
import os, sys, platform

# Must be set BEFORE numpy is imported. Conda environments on Windows frequently end up
# with two Intel OpenMP runtimes (one from MKL/numpy, one from another package). When the
# second initialises, libiomp aborts the process outright — no Python traceback, just a
# dead kernel. This flag tells it to tolerate the duplicate.
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

REPO     = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("GBD_DATA_DIR", os.path.join(REPO, "data"))
HERE = REPO
OUT  = os.path.join(REPO, "outputs")
FIGS = os.path.join(OUT, "figures"); os.makedirs(FIGS, exist_ok=True)
LOG  = os.path.join(FIGS, "_run_log.txt")

open(LOG, "w", encoding="utf-8").close()          # start a fresh log

def log(msg):
    line = f"{msg}"
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n"); f.flush(); os.fsync(f.fileno())
    print(line)

log(f"python      {platform.python_version()}  ({platform.platform()})")
log(f"executable  {sys.executable}")

import numpy as np;  log(f"numpy       {np.__version__}")
import pandas as pd; log(f"pandas      {pd.__version__}")

import matplotlib;   log(f"matplotlib  {matplotlib.__version__}")

# Do NOT force a backend inside a Jupyter kernel. The kernel has already configured
# matplotlib_inline, and switching backends mid-session reloads the rendering DLLs —
# which is where this notebook previously died on Windows/conda. Running the same code
# from a terminal worked precisely because no switch happened. savefig() writes PNG, PDF
# and TIFF correctly under any backend, so there is nothing to gain by forcing one.
IN_KERNEL = "ipykernel" in sys.modules
if IN_KERNEL:
    log("running inside a Jupyter kernel - leaving the active backend alone")
else:
    matplotlib.use("Agg")
    log("running as a script - backend set to Agg")
log(f"backend     {matplotlib.get_backend()}")

log("importing pyplot ...")
import matplotlib.pyplot as plt
log("pyplot imported OK")

# Smallest possible render — if matplotlib is ABI-broken against NumPy 2.x it dies here,
# before any project data is involved, which tells us the maps were never the problem.
plt.ioff()          # keep figures off-screen; every one is written to disk instead
_f, _a = plt.subplots(figsize=(2, 1)); _a.plot([0, 1], [0, 1])
_probe = os.path.join(FIGS, "_probe.png"); _f.savefig(_probe, dpi=72); plt.close(_f)
log("matplotlib PNG render OK")

try:
    _f, _a = plt.subplots(figsize=(2, 1)); _a.plot([0, 1], [0, 1])
    _f.savefig(os.path.join(FIGS, "_probe.tif"), dpi=72, pil_kwargs={"compression": "tiff_lzw"})
    plt.close(_f); log("matplotlib TIFF render OK")
    EXPORT_TIFF = True
except Exception as e:
    log(f"TIFF unavailable, will skip it: {e!r}")
    EXPORT_TIFF = False

for _p in ("_probe.png", "_probe.tif"):
    try: os.remove(os.path.join(FIGS, _p))
    except OSError: pass
log("PREFLIGHT PASSED")

import json, warnings
from matplotlib.path import Path
from matplotlib.patches import PathPatch, Patch
from matplotlib.ticker import FuncFormatter
from matplotlib.colors import TwoSlopeNorm
from matplotlib.cm import ScalarMappable
warnings.filterwarnings("ignore")

m      = pd.read_csv(os.path.join(OUT, "decomposition_by_country_full.csv"), index_col=0)
region = pd.read_csv(os.path.join(OUT, "decomposition_by_superregion.csv"), index_col=0)
income = pd.read_csv(os.path.join(OUT, "decomposition_by_income_group.csv"), index_col=0)
results = json.load(open(os.path.join(OUT, "results.json"), encoding="utf-8"))
log(f"loaded {len(m)} countries, {len(region)} super-regions, {len(income)} income groups")

plt.rcParams.update({
    "font.family":"DejaVu Sans", "font.size":9,
    "axes.titlesize":10, "axes.titleweight":"bold", "axes.labelsize":9,
    "axes.spines.top":False, "axes.spines.right":False,
    "axes.grid":True, "grid.alpha":.25, "grid.linewidth":.6,
    "figure.dpi":150, "savefig.bbox":"tight", "pdf.fonttype":42, "ps.fonttype":42})

PAL = {"exp":"#1B6CA8", "dem":"#E08A1E", "epi":"#7A9E3F", "neg":"#B23A48",
       "declined":"#9AA5B1", "nodata":"#EDEDED"}
LABELS = {"exp":"Exposure (PAF)", "dem":"Population size", "epi":"Background COPD rate"}
THOUS = FuncFormatter(lambda v, _: f"{v:,.0f}")

def save(fig, stem):
    """PNG 600 dpi + vector PDF + optional LZW TIFF, each logged separately."""
    log(f"  [{stem}] saving PNG 600 dpi")
    fig.savefig(os.path.join(FIGS, stem + ".png"), dpi=600)
    log(f"  [{stem}] saving PDF")
    fig.savefig(os.path.join(FIGS, stem + ".pdf"))
    if EXPORT_TIFF:
        log(f"  [{stem}] saving TIFF 600 dpi")
        try:
            fig.savefig(os.path.join(FIGS, stem + ".tif"), dpi=600,
                        pil_kwargs={"compression":"tiff_lzw"})
        except Exception as e:
            log(f"  [{stem}] TIFF failed (continuing): {e!r}")
    fig.savefig(os.path.join(OUT, stem + ".png"), dpi=200)   # copy for the Word build
    plt.close(fig)
    log(f"DONE {stem}")

GEOJSON = os.path.join(HERE, "world_robinson.json")
assert os.path.exists(GEOJSON), (
    f"{GEOJSON} not found — it ships next to this notebook and holds the country outlines.")

_geo = json.load(open(GEOJSON, encoding="utf-8"))
log(f"geometry source: {_geo['_source']}  |  {_geo['_projection']}  |  units {_geo['_units']}")

def _compile_path(parts):
    verts, codes = [], []
    for part in parts:
        for ring in [part["e"]] + part.get("h", []):
            verts.extend(ring); verts.append(ring[0])
            codes.extend([Path.MOVETO] + [Path.LINETO]*(len(ring)-1) + [Path.CLOSEPOLY])
    return Path(np.asarray(verts, dtype=float), codes)

PATHS = {iso: _compile_path(parts) for iso, parts in _geo["countries"].items()}
_all = np.vstack([p.vertices for p in PATHS.values()])
XLIM = (_all[:,0].min()*1.02, _all[:,0].max()*1.02)
YLIM = (_all[:,1].min()*1.05, _all[:,1].max()*1.05)
log(f"{len(PATHS)} country outlines compiled")

def draw_map(ax, colours, default=PAL["nodata"], edge="white", lw=.3):
    """colours: {iso3: any matplotlib colour}. Countries absent from it get `default`."""
    for iso, path in PATHS.items():
        ax.add_patch(PathPatch(path, facecolor=colours.get(iso, default),
                               edgecolor=edge, linewidth=lw))
    ax.set_xlim(*XLIM); ax.set_ylim(*YLIM)
    ax.set_aspect("equal"); ax.set_axis_off()

MANUAL_ISO = {
 "Bolivia (Plurinational State of)":"BOL","Democratic People's Republic of Korea":"PRK",
 "Iran (Islamic Republic of)":"IRN","Micronesia (Federated States of)":"FSM",
 "Republic of Korea":"KOR","Republic of Moldova":"MDA","United Republic of Tanzania":"TZA",
 "Venezuela (Bolivarian Republic of)":"VEN","Viet Nam":"VNM","T\u00fcrkiye":"TUR",
 "Taiwan":"TWN","Palestine":"PSE","C\u00f4te d'Ivoire":"CIV",
 "United States Virgin Islands":"VIR","Czechia":"CZE","Eswatini":"SWZ",
 "North Macedonia":"MKD","Cabo Verde":"CPV","Lao People's Democratic Republic":"LAO",
 "Syrian Arab Republic":"SYR","Democratic Republic of the Congo":"COD","Congo":"COG",
 "Tokelau":"TKL","Niue":"NIU","United Kingdom":"GBR","United States of America":"USA",
 "Sao Tome and Principe":"STP","Saint Kitts and Nevis":"KNA","Saint Lucia":"LCA",
 "Saint Vincent and the Grenadines":"VCT","Brunei Darussalam":"BRN","Cook Islands":"COK",
 "Northern Mariana Islands":"MNP","American Samoa":"ASM"}

try:
    import pycountry
    def to_iso3(name):
        if name in MANUAL_ISO: return MANUAL_ISO[name]
        try: return pycountry.countries.lookup(name).alpha_3
        except LookupError: return None
    m["iso3"] = [to_iso3(c) for c in m.index]
    log("crosswalk built with pycountry")
except ImportError:
    m["iso3"] = pd.read_csv(os.path.join(HERE, "country_iso3.csv"), index_col=0)["iso3"]
    log("pycountry not installed — using the shipped country_iso3.csv")

assert m.iso3.notna().all(), f"unmapped: {list(m.index[m.iso3.isna()])}"
drawn = m.iso3.isin(PATHS)
log(f"{len(m)} countries crosswalked; {int(drawn.sum())} have an outline at 110 m")
log(f"share of 2023 burden represented on the maps: "
    f"{100*m.loc[drawn,'D1'].sum()/m.D1.sum():.1f}%")

def stacked(ax, df, labels, title):
    y = np.arange(len(df))
    series = [(df.exp_effect.values, PAL["exp"], LABELS["exp"]),
              (df.dem_effect.values, PAL["dem"], LABELS["dem"]),
              (df.epi_effect.values, PAL["epi"], LABELS["epi"])]
    pos, neg = np.zeros(len(df)), np.zeros(len(df))
    for vals, col, lab in series:
        left = np.where(vals >= 0, pos, neg + vals)
        ax.barh(y, np.abs(vals), left=left, color=col, label=lab,
                height=.68, edgecolor="white", linewidth=.5)
        pos = pos + np.where(vals >= 0, vals, 0)
        neg = neg + np.where(vals < 0, vals, 0)
    ax.axvline(0, color="#333", lw=.9)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=8)
    ax.invert_yaxis(); ax.set_title(title, loc="left")
    ax.xaxis.set_major_formatter(THOUS)
    ax.set_xlabel("Contribution to change in deaths, 1990\u20132023")
    ax.grid(axis="y", visible=False)

log("--- Fig 1")
CATS = {"Exposure":PAL["exp"], "Population size":PAL["dem"],
        "Background COPD rate":PAL["epi"], "Burden declined":PAL["declined"]}
share = results["leading_driver_burden_share"]

fig, ax = plt.subplots(figsize=(9, 4.6))
draw_map(ax, {r.iso3: CATS[r.leading_driver] for _, r in m.iterrows()})
h = [Patch(facecolor=c, edgecolor="white",
           label=f"{k}  ({share.get(k,0):.0f}% of 2023 burden)") for k, c in CATS.items()]
h.append(Patch(facecolor=PAL["nodata"], edgecolor="white", label="No estimate"))
ax.legend(handles=h, loc="lower center", bbox_to_anchor=(.5,-.13), ncol=2,
          frameon=False, fontsize=8.5, handlelength=1.4)
fig.tight_layout(); save(fig, "Fig1_leading_driver_map")

log("--- Fig 2")
top15 = m.nlargest(15, "D1")
fig, ax = plt.subplots(figsize=(7.2, 5.2))
stacked(ax, top15, top15.index,
        "Decomposition of the change in ozone-attributable COPD deaths, 1990\u20132023")
ax.legend(frameon=False, fontsize=8, loc="lower right")
fig.tight_layout(); save(fig, "Fig2_decomposition_top15")

log("--- Fig 3")
INC_ORDER = ["Low-income","Lower-middle income","Upper-middle income","High-income"]
order = [i for i in INC_ORDER if i in income.index]

fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
stacked(axes[0], region, region.index, "A. By GBD super-region")
stacked(axes[1], income.loc[order], ["Low","Lower-middle","Upper-middle","High"],
        "B. By World Bank income group")
axes[1].legend(frameon=False, fontsize=8, loc="lower right")
fig.tight_layout(); save(fig, "Fig3_decomposition_region_income")

log("--- Fig 4")
norm = TwoSlopeNorm(vmin=-100, vcenter=0, vmax=100)
cmap = plt.get_cmap("RdBu_r")

fig, ax = plt.subplots(figsize=(9, 4.6))
draw_map(ax, {r.iso3: cmap(norm(r.expshare))
              for _, r in m.iterrows() if pd.notna(r.expshare)})
cb = fig.colorbar(ScalarMappable(norm=norm, cmap=cmap), ax=ax, orientation="horizontal",
                  fraction=.036, pad=.03, aspect=38, ticks=[-100,-50,0,50,100])
cb.ax.set_xticklabels(["\u2212100%\naverted","\u221250%","0","+50%","+100%\nexcess"], fontsize=8)
cb.set_label("Share of 2023 burden attributable to the change in ozone exposure since 1990",
             fontsize=8.5, labelpad=6)
cb.outline.set_visible(False)
fig.tight_layout(); save(fig, "Fig4_counterfactual_map")

log("--- Fig 5")
cf = m.nlargest(12, "D1").sort_values("excess_from_exposure")
fig, ax = plt.subplots(figsize=(7.2, 4.4))
ax.barh(np.arange(len(cf)), cf.excess_from_exposure,
        color=[PAL["neg"] if v > 0 else PAL["exp"] for v in cf.excess_from_exposure], height=.68)
ax.axvline(0, color="#333", lw=.9)
ax.set_yticks(np.arange(len(cf))); ax.set_yticklabels(cf.index, fontsize=8)
ax.set_xlabel("Deaths in 2023 attributable to the change in ozone exposure since 1990")
ax.set_title("Excess (red) or averted (blue) 2023 deaths versus a 1990-exposure counterfactual",
             loc="left")
ax.xaxis.set_major_formatter(THOUS); ax.grid(axis="y", visible=False)
fig.tight_layout(); save(fig, "Fig5_counterfactual_bar")

log("--- Fig S1")
BINS = [0,.5,1,2,5,10,20]
LABS = ["<0.5","0.5\u20131","1\u20132","2\u20135","5\u201310","\u226510"]
COLS = ["#FEF0D9","#FDD49E","#FDBB84","#FC8D59","#E34A33","#A02D18"]
bin_of = lambda v: COLS[min(int(np.searchsorted(BINS, v, side="right")) - 1, len(COLS)-1)]

fig, ax = plt.subplots(figsize=(9, 4.6))
draw_map(ax, {r.iso3: bin_of(r.crude_rate_2023)
              for _, r in m.iterrows() if pd.notna(r.crude_rate_2023)})
h = [Patch(facecolor=c, edgecolor="white", label=l) for c, l in zip(COLS, LABS)]
h.append(Patch(facecolor=PAL["nodata"], edgecolor="white", label="No estimate"))
ax.legend(handles=h, loc="lower center", bbox_to_anchor=(.5,-.11), ncol=7, frameon=False,
          fontsize=8.5, handlelength=1.2, columnspacing=1.1,
          title="Crude ozone-attributable COPD deaths per 100 000, 2023", title_fontsize=8.5)
fig.tight_layout(); save(fig, "FigS1_crude_rate_map")

m[["iso3","leading_driver","expshare","crude_rate_2023"]].to_csv(
    os.path.join(OUT, "map_data.csv"))
log("ALL FIGURES COMPLETE")

print("Figures written to", FIGS)
for f in sorted(os.listdir(FIGS)):
    if not f.startswith("_"): print("  ", f)
print("\nRun log:", LOG)
print("\nNext: 03_build_manuscript.ipynb")
