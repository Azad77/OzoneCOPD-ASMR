# How to push this to GitHub

The repository currently holds one file (`Supplementary Data.docx`) and one commit. These
instructions replace its contents with the full reproducible pipeline.

## 1. Copy this folder onto your machine

Everything in `github_repo\` is the intended repository content. Copy it somewhere outside
`D:\air_pollution_GBD_2023` — for example `D:\repos\OzoneCOPD-ASMR` — so the working copy is
separate from your project folder.

## 2. Push

```bat
cd /d D:\repos\OzoneCOPD-ASMR

git init
git branch -M main
git remote add origin https://github.com/Azad77/OzoneCOPD-ASMR.git

REM keep whatever is already on GitHub, then add everything here on top
git fetch origin
git checkout -b main origin/main 2>nul || git branch -M main

git add .
git commit -m "Add reproducible analysis pipeline, data extracts, figures and manuscript"
git push -u origin main
```

If the push is rejected because histories differ, either merge:

```bat
git pull origin main --allow-unrelated-histories
git push -u origin main
```

or, if you are content to replace the repository contents entirely:

```bat
git push -u origin main --force
```

GitHub will prompt for credentials. Use a **personal access token** as the password, not your
account password — create one at Settings → Developer settings → Personal access tokens, with the
`repo` scope.

## 3. Two settings to change on github.com

**Update the description.** It currently reads *"Age-standardised ozone-attributable COPD death
rates per 100 000 population for all countries, 2023"*, which is no longer accurate — the analysis
reports crude rates, and the repository is now the whole pipeline. Suggested replacement:

> Reproducible Das Gupta decomposition of ozone-attributable COPD mortality, 1990–2023, across 204
> countries (GBD 2023). Every number in the manuscript is generated, not transcribed.

**Consider the repository name.** `OzoneCOPD-ASMR` refers to age-standardised mortality rates,
which the analysis no longer uses. GitHub permanently redirects the old URL after a rename, so
nothing breaks — but the manuscript and cover letter both cite
`https://github.com/Azad77/OzoneCOPD-ASMR`, so renaming means updating those two documents. Keeping
the name is perfectly defensible; just be aware it is a legacy label.

## 4. Optional: get a DOI

Connect the repository to [Zenodo](https://zenodo.org/account/settings/github/) and cut a release.
Zenodo mints a DOI you can cite in the Data Availability statement, which is stronger than a bare
GitHub URL because it is versioned and permanent. `CITATION.cff` is already in place, so GitHub
will show a "Cite this repository" button once pushed.

## 5. Before pushing, check

- [ ] You are comfortable redistributing the GBD extracts in `data/` (744 KB). They fall under the
      IHME Free-of-Charge Non-Commercial User Agreement; `LICENSE` and `data/citation.txt` record
      this. Delete `data/` if you would rather not, but note the pipeline is then not runnable from
      a clean clone.
- [ ] `LICENSE` says MIT with your name. Change it if you prefer a different licence.
- [ ] Nothing private is in the folder — no credentials, no unpublished co-author material.
